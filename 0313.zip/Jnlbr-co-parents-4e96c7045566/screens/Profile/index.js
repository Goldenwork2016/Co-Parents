import Profile from './Profile';
// import { connect } from 'react-redux'

// const mapStateToProps = (state) => ({
// });

// const mapDispatchToProps = {  
// }

export default Profile // connect(mapStateToProps, mapDispatchToProps)(Profile);