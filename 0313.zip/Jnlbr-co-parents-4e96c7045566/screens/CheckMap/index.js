import CheckMap from './CheckMap';

export default CheckMap;