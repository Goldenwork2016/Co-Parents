export {default as FamilyBackground} from './family';
export {default as CurvedBackground} from './Curved';