export const ADD_CHILD = 'ADD_CHILD';
export const REMOVE_CHILD = 'REMOVE_CHILD';
export const SET_CHILDREN = 'SET_CHILDREN';