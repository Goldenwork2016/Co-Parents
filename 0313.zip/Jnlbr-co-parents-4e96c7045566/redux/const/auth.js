export const SET_TOKEN = 'SET_TOKEN';
export const SET_TYPE = 'SET_TYPE';