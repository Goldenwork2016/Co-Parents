# Co-parents

### TODO

1. Setup for Facebook authentication on iOS