export default {
  green: '#82C84F',
  gray:'#7B7B7B',
  grayDark: '#515450',
  background: '#F6F6F6',
  textDark: '#6d6d6d',
  textLight: '#b5b5b5',
  headerTitle: '#8f8f8f'
}